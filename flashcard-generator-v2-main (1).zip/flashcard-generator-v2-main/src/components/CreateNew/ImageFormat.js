// image formats for image upload check
export const IMAGE_FORMATS = [
  "image/gif",
  "image/webp",
  "image/svg+xml",
  "image/avif",
  "image/apng",
  "image/jpg",
  "image/jpeg",
  "image/png",
];

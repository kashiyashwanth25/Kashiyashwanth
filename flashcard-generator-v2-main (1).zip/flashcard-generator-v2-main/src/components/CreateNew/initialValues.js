// initial values for the forms for redux
export const initialValues = {
  cardName: "",
  cardDesc: "",
  cardImg: "",
  terms: [{ id: 0, termName: "", termDef: "", termImg: "" }],
};
